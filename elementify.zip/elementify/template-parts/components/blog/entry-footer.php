<?php
/**
 * Template part for displaying post entry footer
 *
 * @package Elementify
 */
?>
<footer class="entry-footer">

	<?php elementify_entry_footer(); ?>
	
</footer><!-- .entry-footer -->
